# ShareBox

[English](README.md) | [简体中文](README.zh-CN.md)

**Fast Wi-Fi file transfer between an Android phone and any computer or phone — with nothing to install on the other side.**

ShareBox turns your Android phone into a tiny file server. On the computer (Windows, Linux, macOS) or on another phone, you only need a web browser. It was built by a Linux user who constantly switches distributions (Ubuntu, Debian, …) and wants to move files without installing anything.

## Features

- **Zero install on the other side** — any modern browser works: Windows, Ubuntu, Debian, other Linux distributions, macOS, another Android phone or an iPhone.
- **Browse the whole phone** — navigate every folder of the phone's storage from the browser, download files, delete files or folders.
- **Drag-and-drop upload** — drop several files at once; each file has its own progress bar. Uploads go into the folder you are currently viewing.
- **Command-line upload** — one `curl` command from a terminal; the exact command (with the current access code) is shown on the phone.
- **Fast** — plain HTTP over your local Wi-Fi, large files are streamed. Real speed depends on your Wi-Fi (typically 30–100 MB/s on 5 GHz / Wi-Fi 6).
- **Works without a router** — turn on the phone's hotspot and connect the computer to it.
- **Phone to phone** — the second phone just opens the address in its browser.
- **Stays alive with the screen off** — runs as a foreground service with a Wi-Fi lock and a wake lock.
- **Bilingual UI (English / 简体中文)** — the phone app follows the system language; the web page follows the browser language and has a language switch button.
- **Dark theme** on both the phone app and the web page.

## Security

ShareBox is meant for a trusted local network (home Wi-Fi or your own hotspot).

- A random **6-digit access code is generated every time the service starts**. Old codes and already logged-in browsers stop working immediately.
- A **"Change access code" button** on the phone invalidates every session at any time.
- **Brute-force protection** — 5 wrong attempts from one device lock that device out for 5 minutes.
- After logging in, the code is removed from the address bar and the session cookie is `HttpOnly` / `SameSite=Strict`.
- Several people can be logged in at the same time with the same code; they all see the same files with the same rights.

**Limitations:** traffic is plain HTTP, so someone sniffing the same Wi-Fi could read the code and the transferred data. Avoid public Wi-Fi. HTTPS is not supported yet.

## Usage

1. Install the APK and open ShareBox. On first launch grant the **All files access** permission (and notifications on Android 13+).
2. Tap **Start**. The phone shows an address such as `192.168.0.9:8080` and a 6-digit access code.
3. Make sure the computer is on the **same Wi-Fi** (or connected to the phone's hotspot).
4. Type the address into the browser (no need to write `http://`; if a browser forces `https`, type `http://` explicitly) and enter the access code.
5. Browse, upload, download or delete.

Command-line upload (the phone displays this line for you):

```bash
curl -T app.apk "http://192.168.0.9:8080/put/app.apk?k=123456"
```

Files uploaded this way go to `Download/ShareBox` by default. Append `&p=Some/Folder` to choose another folder (path relative to the phone's storage root).

## Build

Requirements: Android 8.0+ (minSdk 26). Written in Kotlin with [NanoHTTPD](https://github.com/NanoHttpd/nanohttpd) as the only dependency.

**Android Studio / Gradle**

```bash
gradle assembleDebug     # APK: app/build/outputs/apk/debug/
```

**GitHub Actions** — `.github/workflows/build.yml` builds the APK on every push and uploads it as an artifact.

**Phone-only workflow (no folder upload needed)** — GitHub's mobile web UI cannot upload folders. Put a single `.zip` of the project in the repository root together with the "Build from zip" workflow: the workflow unzips it, builds the APK and publishes it on the **Releases** page, where you can download it straight to the phone.

> Debug builds are signed with a different key on every CI run, so Android refuses to update over a previous build. Uninstall the old version first, or add a fixed keystore.

## Project structure

```
app/src/main/
├── java/com/sharebox/
│   ├── MainActivity.kt    # phone UI: start/stop, address, access code
│   ├── ShareService.kt    # foreground service, wake/Wi-Fi locks, access code
│   └── Server.kt          # HTTP server: login, list, download, upload, delete
├── assets/index.html      # the web page served to the browser (EN/中文)
└── res/                   # strings (en / zh), launcher icons
```

## HTTP endpoints

| Endpoint | Purpose |
|---|---|
| `GET /` | web UI |
| `GET /api/list?p=<dir>` | list a folder |
| `GET /f?p=<file>` | download a file |
| `POST /api/upload?p=<dir>` | upload a file (multipart, field `file`) |
| `PUT /put/<name>?p=<dir>` | raw upload for `curl -T` |
| `POST /api/delete?p=<path>` | delete a file or folder |

Every request needs the access code (`?k=` or the login cookie). Paths are always resolved inside the phone's storage root; `..` escapes are rejected.

## Roadmap

- Download a whole folder as a ZIP
- Resumable downloads (HTTP Range)
- Optional HTTPS with a self-signed certificate
- QR code for phone-to-phone connection
- WebDAV so that Linux file managers can mount the phone
- Per-user permissions (e.g. download-only)
- Fixed signing key for in-place updates

## License

Not specified yet — add a `LICENSE` file of your choice.
