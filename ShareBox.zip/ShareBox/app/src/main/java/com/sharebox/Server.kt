package com.sharebox

import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.URLConnection
import java.net.URLDecoder

class Server(private val dir: File, private val token: String, private val page: String, port: Int) : NanoHTTPD(port) {

    private fun text(st: Response.IStatus, msg: String, mime: String = "text/plain; charset=utf-8") =
        newFixedLengthResponse(st, mime, msg)

    override fun serve(s: IHTTPSession): Response {
        return try {
            val qOk = s.parameters["k"]?.firstOrNull() == token
            val cOk = s.headers["cookie"]?.contains("k=$token") == true
            if (!qOk && !cOk) return text(Response.Status.UNAUTHORIZED,
                "<meta charset=utf-8><form>访问码: <input name=k> <button>进入</button></form>", "text/html; charset=utf-8")
            val r = route(s)
            if (qOk) r.addHeader("Set-Cookie", "k=$token; Path=/")
            r
        } catch (e: Exception) {
            text(Response.Status.INTERNAL_ERROR, "error: ${e.message}")
        }
    }

    private fun route(s: IHTTPSession): Response {
        val uri = s.uri
        return when {
            uri == "/" -> text(Response.Status.OK, page, "text/html; charset=utf-8")
            uri == "/api/list" -> {
                val arr = JSONArray()
                (dir.listFiles() ?: emptyArray()).filter { it.isFile }.sortedByDescending { it.lastModified() }
                    .forEach { arr.put(JSONObject().put("name", it.name).put("size", it.length())) }
                text(Response.Status.OK, arr.toString(), "application/json")
            }
            uri.startsWith("/f/") -> {
                val f = File(dir, File(URLDecoder.decode(uri.substring(3), "UTF-8")).name)
                if (!f.isFile) return text(Response.Status.NOT_FOUND, "not found")
                val mime = URLConnection.guessContentTypeFromName(f.name) ?: "application/octet-stream"
                val r = newFixedLengthResponse(Response.Status.OK, mime, FileInputStream(f), f.length())
                r.addHeader("Content-Disposition", "attachment; filename*=UTF-8''" + java.net.URLEncoder.encode(f.name, "UTF-8").replace("+", "%20"))
                r
            }
            uri == "/api/upload" && s.method == Method.POST -> {
                val files = HashMap<String, String>()
                s.parseBody(files)
                val tmp = files["file"] ?: return text(Response.Status.BAD_REQUEST, "no file")
                save(File(tmp), s.parameters["file"]?.firstOrNull() ?: "upload.bin")
                text(Response.Status.OK, "ok")
            }
            uri.startsWith("/put/") && s.method == Method.PUT -> {   // curl -T 用
                val files = HashMap<String, String>()
                s.parseBody(files)
                val tmp = files["content"] ?: return text(Response.Status.BAD_REQUEST, "no body")
                save(File(tmp), URLDecoder.decode(uri.substring(5), "UTF-8"))
                text(Response.Status.OK, "ok\n")
            }
            uri == "/api/delete" && s.method == Method.POST -> {
                File(dir, File(s.parameters["name"]?.firstOrNull() ?: "").name).takeIf { it.isFile }?.delete()
                text(Response.Status.OK, "ok")
            }
            else -> text(Response.Status.NOT_FOUND, "not found")
        }
    }

    private fun save(tmp: File, name: String) {
        val dst = File(dir, File(name).name)
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, true); tmp.delete() }
    }
}
