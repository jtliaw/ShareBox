package com.sharebox

import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.URLConnection
import java.net.URLDecoder

class Server(private val root: File, private val tokenOf: () -> String, private val page: String, port: Int) : NanoHTTPD(port) {
    private val rootPath = root.canonicalPath

    private fun text(st: Response.IStatus, msg: String, mime: String = "text/plain; charset=utf-8") =
        newFixedLengthResponse(st, mime, msg)

    private fun q(s: IHTTPSession, k: String) = s.parameters[k]?.firstOrNull()

    private fun resolve(p: String?): File? {
        val f = File(root, p ?: "").canonicalFile
        return if (f.path == rootPath || f.path.startsWith("$rootPath/")) f else null
    }

    private val fails = HashMap<String, Pair<Int, Long>>()   // ip -> (失败次数, 解锁时间)
    private val tooMany = object : Response.IStatus {
        override fun getRequestStatus() = 429
        override fun getDescription() = "429 Too Many Requests"
    }
    private fun same(a: String?, b: String) = a != null && java.security.MessageDigest.isEqual(a.toByteArray(), b.toByteArray())
    private val loginPage = "<meta charset=utf-8><meta name=viewport content=\"width=device-width,initial-scale=1\"><body style=\"background:#121212;color:#eee;font:24px system-ui;padding:12vw 6vw\"><form>访问码 / Access code<br><input name=k inputmode=numeric autofocus style=\"font-size:32px;width:100%;box-sizing:border-box;margin:16px 0;padding:12px\"><button style=\"font-size:28px;width:100%;padding:14px\">进入 / Enter</button></form>"

    override fun serve(s: IHTTPSession): Response {
        return try {
            val token = tokenOf()
            val ip = s.remoteIpAddress ?: "?"
            val now = System.currentTimeMillis()
            synchronized(fails) {
                val f = fails[ip]
                if (f != null && f.second > now)
                    return text(tooMany, "尝试次数过多，请 5 分钟后再试 / Too many attempts. Try again in 5 minutes.", "text/plain; charset=utf-8")
            }
            val kq = q(s, "k")
            val ck = Regex("(?:^|;\\s*)k=([^;]*)").find(s.headers["cookie"] ?: "")?.groupValues?.get(1)
            val qOk = same(kq, token)
            val cOk = same(ck, token)
            if (!qOk && !cOk) {
                if (kq != null || ck != null) synchronized(fails) {
                    val n = (fails[ip]?.first ?: 0) + 1
                    fails[ip] = if (n >= 5) Pair(0, now + 5 * 60_000L) else Pair(n, 0L)
                }
                return text(Response.Status.UNAUTHORIZED, loginPage, "text/html; charset=utf-8")
            }
            synchronized(fails) { fails.remove(ip) }
            val cookie = "k=$token; Path=/; HttpOnly; SameSite=Strict"
            if (qOk && s.uri == "/") {   // 登录成功后跳到干净的网址，访问码不留在地址栏
                val r = newFixedLengthResponse(Response.Status.REDIRECT_SEE_OTHER, "text/plain", "")
                r.addHeader("Location", "/"); r.addHeader("Set-Cookie", cookie)
                return r
            }
            val r = route(s)
            if (qOk) r.addHeader("Set-Cookie", cookie)
            r
        } catch (e: Exception) {
            text(Response.Status.INTERNAL_ERROR, "error: ${e.message}")
        }
    }

    private fun route(s: IHTTPSession): Response {
        val uri = s.uri
        val p = q(s, "p")   // 必须在 parseBody 之前读取
        val bad = text(Response.Status.BAD_REQUEST, "bad path")
        return when {
            uri == "/" -> text(Response.Status.OK, page, "text/html; charset=utf-8")
            uri == "/api/list" -> {
                val d = resolve(p) ?: return bad
                val list = d.listFiles()
                val arr = JSONArray()
                (list ?: emptyArray()).sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
                    .forEach { arr.put(JSONObject().put("name", it.name).put("size", it.length()).put("dir", it.isDirectory)) }
                text(Response.Status.OK, JSONObject().put("items", arr).put("denied", list == null).toString(), "application/json")
            }
            uri == "/f" -> {
                val f = resolve(p) ?: return bad
                if (!f.isFile) return text(Response.Status.NOT_FOUND, "not found")
                val mime = URLConnection.guessContentTypeFromName(f.name) ?: "application/octet-stream"
                val r = newFixedLengthResponse(Response.Status.OK, mime, FileInputStream(f), f.length())
                r.addHeader("Content-Disposition", "attachment; filename*=UTF-8''" + java.net.URLEncoder.encode(f.name, "UTF-8").replace("+", "%20"))
                r
            }
            uri == "/api/upload" && s.method == Method.POST -> {
                val dir = resolve(p) ?: return bad
                val files = HashMap<String, String>()
                s.parseBody(files)
                val tmp = files["file"] ?: return text(Response.Status.BAD_REQUEST, "no file")
                save(File(tmp), dir, s.parameters["file"]?.firstOrNull() ?: "upload.bin")
                text(Response.Status.OK, "ok")
            }
            uri.startsWith("/put/") && s.method == Method.PUT -> {   // curl -T 用，默认放 Download/ShareBox
                val dir = resolve(p ?: "Download/ShareBox") ?: return bad
                val files = HashMap<String, String>()
                s.parseBody(files)
                val tmp = files["content"] ?: return text(Response.Status.BAD_REQUEST, "no body")
                save(File(tmp), dir, URLDecoder.decode(uri.substring(5), "UTF-8"))
                text(Response.Status.OK, "ok\n")
            }
            uri == "/api/delete" && s.method == Method.POST -> {
                val f = resolve(p) ?: return bad
                if (f.path == rootPath) return bad
                f.deleteRecursively()
                text(Response.Status.OK, "ok")
            }
            else -> text(Response.Status.NOT_FOUND, "not found")
        }
    }

    private fun save(tmp: File, dir: File, name: String) {
        dir.mkdirs()
        val dst = File(dir, File(name).name)
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, true); tmp.delete() }
    }
}
