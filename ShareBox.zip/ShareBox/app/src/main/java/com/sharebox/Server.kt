package com.sharebox

import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.URLConnection
import java.net.URLDecoder

class Server(private val root: File, private val token: String, private val page: String, port: Int) : NanoHTTPD(port) {
    private val rootPath = root.canonicalPath

    private fun text(st: Response.IStatus, msg: String, mime: String = "text/plain; charset=utf-8") =
        newFixedLengthResponse(st, mime, msg)

    private fun q(s: IHTTPSession, k: String) = s.parameters[k]?.firstOrNull()

    private fun resolve(p: String?): File? {
        val f = File(root, p ?: "").canonicalFile
        return if (f.path == rootPath || f.path.startsWith("$rootPath/")) f else null
    }

    override fun serve(s: IHTTPSession): Response {
        return try {
            val qOk = q(s, "k") == token
            val cOk = s.headers["cookie"]?.contains("k=$token") == true
            if (!qOk && !cOk) return text(Response.Status.UNAUTHORIZED,
                "<meta charset=utf-8><form>访问码: <input name=k> <button>进入</button></form>", "text/html; charset=utf-8")
            val r = route(s)
            if (qOk) r.addHeader("Set-Cookie", "k=$token; Path=/")
            r
        } catch (e: Exception) {
            text(Response.Status.INTERNAL_ERROR, "error: ${e.message}")
        }
    }

    private fun route(s: IHTTPSession): Response {
        val uri = s.uri
        val p = q(s, "p")   // 必须在 parseBody 之前读取
        val bad = text(Response.Status.BAD_REQUEST, "bad path")
        return when {
            uri == "/" -> text(Response.Status.OK, page, "text/html; charset=utf-8")
            uri == "/api/list" -> {
                val d = resolve(p) ?: return bad
                val list = d.listFiles()
                val arr = JSONArray()
                (list ?: emptyArray()).sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
                    .forEach { arr.put(JSONObject().put("name", it.name).put("size", it.length()).put("dir", it.isDirectory)) }
                text(Response.Status.OK, JSONObject().put("items", arr).put("denied", list == null).toString(), "application/json")
            }
            uri == "/f" -> {
                val f = resolve(p) ?: return bad
                if (!f.isFile) return text(Response.Status.NOT_FOUND, "not found")
                val mime = URLConnection.guessContentTypeFromName(f.name) ?: "application/octet-stream"
                val r = newFixedLengthResponse(Response.Status.OK, mime, FileInputStream(f), f.length())
                r.addHeader("Content-Disposition", "attachment; filename*=UTF-8''" + java.net.URLEncoder.encode(f.name, "UTF-8").replace("+", "%20"))
                r
            }
            uri == "/api/upload" && s.method == Method.POST -> {
                val dir = resolve(p) ?: return bad
                val files = HashMap<String, String>()
                s.parseBody(files)
                val tmp = files["file"] ?: return text(Response.Status.BAD_REQUEST, "no file")
                save(File(tmp), dir, s.parameters["file"]?.firstOrNull() ?: "upload.bin")
                text(Response.Status.OK, "ok")
            }
            uri.startsWith("/put/") && s.method == Method.PUT -> {   // curl -T 用，默认放 Download/ShareBox
                val dir = resolve(p ?: "Download/ShareBox") ?: return bad
                val files = HashMap<String, String>()
                s.parseBody(files)
                val tmp = files["content"] ?: return text(Response.Status.BAD_REQUEST, "no body")
                save(File(tmp), dir, URLDecoder.decode(uri.substring(5), "UTF-8"))
                text(Response.Status.OK, "ok\n")
            }
            uri == "/api/delete" && s.method == Method.POST -> {
                val f = resolve(p) ?: return bad
                if (f.path == rootPath) return bad
                f.deleteRecursively()
                text(Response.Status.OK, "ok")
            }
            else -> text(Response.Status.NOT_FOUND, "not found")
        }
    }

    private fun save(tmp: File, dir: File, name: String) {
        dir.mkdirs()
        val dst = File(dir, File(name).name)
        if (!tmp.renameTo(dst)) { tmp.copyTo(dst, true); tmp.delete() }
    }
}
