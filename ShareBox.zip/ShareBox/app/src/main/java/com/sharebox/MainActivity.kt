package com.sharebox

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var btn: Button
    private lateinit var btn2: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 120, 48, 48); setBackgroundColor(0xFF121212.toInt()) }
        info = TextView(this).apply { textSize = 18f; setTextIsSelectable(true); setTextColor(0xFFE8E8E8.toInt()) }
        btn = Button(this)
        btn2 = Button(this).apply { text = getString(R.string.change_code) }
        l.addView(info); l.addView(btn); l.addView(btn2); setContentView(l)
        btn.setOnClickListener {
            val i = Intent(this, ShareService::class.java)
            if (ShareService.running) stopService(i) else startForegroundService(i)
            btn.postDelayed({ refresh() }, 500)
        }
        btn2.setOnClickListener { ShareService.newToken(); refresh() }
        perms()
    }

    private fun perms() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager())
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val ips = ShareService.ips()
        val k = ShareService.token
        info.text = if (ShareService.running)
            getString(R.string.running_head) + "\n\n" + ips.joinToString("\n") { "$it:${ShareService.PORT}" } +
                "\n\n" + getString(R.string.code_line, k) + "\n\n" + getString(R.string.browse_note) +
                "\n\n" + getString(R.string.curl_head) + "\ncurl -T FILE \"http://${ips.firstOrNull() ?: "IP"}:${ShareService.PORT}/put/NAME?k=$k\""
        else getString(R.string.stopped)
        btn.text = getString(if (ShareService.running) R.string.stop else R.string.start)
        btn2.visibility = if (ShareService.running) View.VISIBLE else View.GONE
    }
}
