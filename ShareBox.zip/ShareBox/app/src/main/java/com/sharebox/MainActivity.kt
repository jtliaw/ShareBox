package com.sharebox

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var btn: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 120, 48, 48) }
        info = TextView(this).apply { textSize = 18f; setTextIsSelectable(true) }
        btn = Button(this)
        l.addView(info); l.addView(btn); setContentView(l)
        btn.setOnClickListener {
            val i = Intent(this, ShareService::class.java)
            if (ShareService.running) stopService(i) else startForegroundService(i)
            btn.postDelayed({ refresh() }, 500)
        }
        perms()
    }

    private fun perms() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager())
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val ips = ShareService.ips()
        val k = ShareService.token(this)
        info.text = if (ShareService.running)
            "已开启。电脑浏览器地址栏输入：\n\n" + ips.joinToString("\n") { "$it:${ShareService.PORT}" } +
                "\n\n访问码：$k\n\n文件夹：Download/ShareBox\n\n电脑命令行上传：\ncurl -T 文件 \"http://${ips.firstOrNull() ?: "IP"}:${ShareService.PORT}/put/文件名?k=$k\""
        else "未开启。点下面按钮启动。\n（首次使用请授予“所有文件访问”权限）"
        btn.text = if (ShareService.running) "停止" else "启动"
    }
}
