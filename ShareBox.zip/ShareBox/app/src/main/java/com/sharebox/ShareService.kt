package com.sharebox

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

class ShareService : Service() {
    private var server: Server? = null
    private var wl: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    companion object {
        const val PORT = 8080
        @Volatile var running = false

        fun dir(): File = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ShareBox").apply { mkdirs() }

        fun token(c: Context): String {
            val p = c.getSharedPreferences("p", MODE_PRIVATE)
            return p.getString("t", null) ?: (100000..999999).random().toString().also { p.edit().putString("t", it).apply() }
        }

        fun ips(): List<String> = NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }.flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && it.isSiteLocalAddress }.map { it.hostAddress!! }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("share", "ShareBox", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "share").setContentTitle("ShareBox 运行中")
            .setSmallIcon(android.R.drawable.stat_sys_upload).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)

        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sharebox:wl").apply { acquire() }
        wifi = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sharebox:wifi").apply { acquire() }

        System.setProperty("java.io.tmpdir", (externalCacheDir ?: cacheDir).absolutePath)
        val page = assets.open("index.html").bufferedReader().readText()
        server = Server(dir(), token(this), page, PORT).also { it.start(300000, false) }
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop(); wl?.release(); wifi?.release(); running = false
        super.onDestroy()
    }
}
